package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Array;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Button r1, r2, r3, r4;
    Button bProx;
    TextView pergunta;
    ArrayList<Pergunta> quiz;
    int pontos = 0;
    int posicao = 0;

    private void iniciarPerguntas(){
        quiz = new ArrayList<>();
        quiz.add(new Pergunta("Qual a capital do Japão?", "Quioto", "Tóquio", "Hiroshima", "Osaka", "Tóquio"));
        quiz.add(new Pergunta("Qual dessas NÃO é uma linguagem de programação?", "PHP", "JavaScript", "C++", "HTML", "HTML"));
        quiz.add(new Pergunta("Qual o maior país do mundo?", "Rússia", "China", "Estados Unidos", "África do sul", "Rússia"));
        quiz.add(new Pergunta("Quantos jogos tem a franquia 'Assassin's Creed'?", "12", "15", "21", "10", "12"));
        quiz.add(new Pergunta("Qual destes personagens ficou vivo até o fim de Demon Slayer", "Tomioka", "Kanroji", "Tokito", "Rengoku", "Tomioka"));
    }
    private void setarQuestao(int i){
        pergunta.setText(quiz.get(i).getQuestao());
        r1.setText(quiz.get(i).getOpcao1());
        r2.setText(quiz.get(i).getOpcao2());
        r3.setText(quiz.get(i).getOpcao3());
        r4.setText(quiz.get(i).getOpcao4());
        r1.setEnabled(true);
        r2.setEnabled(true);
        r3.setEnabled(true);
        r4.setEnabled(true);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        r1 = findViewById(R.id.id_resp1);
        r2 = findViewById(R.id.id_resp2);
        r3 = findViewById(R.id.id_resp3);
        r4 = findViewById(R.id.id_resp4);

        bProx = findViewById(R.id.id_proximo);
        pergunta = findViewById(R.id.id_pergunta);
        iniciarPerguntas();
        setarQuestao(0);

        r1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              if(quiz.get(posicao).getResposta().trim().toLowerCase().equals(r1.getText().toString().trim().toLowerCase())){
                  pontos++;
                  Toast.makeText(MainActivity.this, "Parabéns Você acertou !!! \n A resposta correta é "+quiz.get(posicao).getResposta(), Toast.LENGTH_LONG).show();
              }else{
                  Toast.makeText(MainActivity.this, "Você errou :( \n A resposta correta é "+quiz.get(posicao).getResposta(), Toast.LENGTH_LONG).show();
              }
            }
        });

        r2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(quiz.get(posicao).getResposta().trim().toLowerCase().equals(r2.getText().toString().trim().toLowerCase())){
                    pontos++;
                    Toast.makeText(MainActivity.this, "Parabéns Você acertou !!! \n A resposta correta é "+quiz.get(posicao).getResposta(), Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(MainActivity.this, "Você errou :( \n A resposta correta é "+quiz.get(posicao).getResposta(), Toast.LENGTH_LONG).show();
                }
            }
        });

        r3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(quiz.get(posicao).getResposta().trim().toLowerCase().equals(r3.getText().toString().trim().toLowerCase())){
                    pontos++;
                    Toast.makeText(MainActivity.this, "Parabéns Você acertou !!! \n A resposta correta é "+quiz.get(posicao).getResposta(), Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(MainActivity.this, "Você errou :( \n A resposta correta é "+quiz.get(posicao).getResposta(), Toast.LENGTH_LONG).show();
                }
            }
        });

        r4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(quiz.get(posicao).getResposta().trim().toLowerCase().equals(r4.getText().toString().trim().toLowerCase())){
                    pontos++;
                    Toast.makeText(MainActivity.this, "Parabéns Você acertou !!! \n A resposta correta é "+quiz.get(posicao).getResposta(), Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(MainActivity.this, "Você errou :( \n A resposta correta é "+quiz.get(posicao).getResposta(), Toast.LENGTH_LONG).show();
                }
            }
        });

        bProx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                posicao++;
                if(posicao < quiz.size()){
                    setarQuestao(posicao);
                }else if(posicao >= quiz.size()){
                    Toast.makeText(MainActivity.this,"Você acertou "+pontos+" questões ", Toast.LENGTH_LONG).show();
                }
            }
        });

    }
}